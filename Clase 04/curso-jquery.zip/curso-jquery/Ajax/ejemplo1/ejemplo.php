<?php

$mensaje="la solicitud fue exitosa archivo php ejemplo";

echo $mensaje;




?>