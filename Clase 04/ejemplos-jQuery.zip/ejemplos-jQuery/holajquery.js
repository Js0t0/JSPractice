// $(document).ready(saluda)

// function saluda()
// {
// alert($('h1').text())
// }
// $(function()
//  {
//     //alert($('h1').text()) 
//     //se crea un parrafo nuevo 
//     //en un objeto jQuery
//     $nuevo  = $('<p>Parrafo nuevo</p>')
//     $('h2').after($nuevo)
//  })

// $('#boton1').click(function (e) { 
//     e.preventDefault();
    
    
// });

//  $(selector).on(events, function () {
     
//  });